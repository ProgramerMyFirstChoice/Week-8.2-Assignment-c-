﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8._2ClassWithMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCylinder_Click(object sender, EventArgs e)
        {
            // Clear all previous(if any) display from richbox  for new calcualtion
            richDisplay.Clear();

            // Check the presence of a value in textbox fisrt using validation method
            if (IsPresent(txtRadius) && IsPresent(txtHeight))
            {
                // Check if the user input value is double type
                if (IsDOuble(txtRadius) && IsDOuble(txtHeight))
                {
                    // Collect and assign user input to a respective variable
                    double radius = double.Parse(txtRadius.Text);
                    double height = double.Parse(txtHeight.Text);
                                       
                    // Create object for class Cylinder and take the dimension 
                    // of cylinder as argumnet Example Two
                    Shape cylinder = new Shape(radius, height);

                    // Get the cylinder Length 
                    cylinder.Radius = radius;

                    // Get the cylinder Height
                    cylinder.Height = height;


                    double volumeResult = cylinder.VolumeCylinder();
                    richDisplay.AppendText("\nTotal Volume of cylinder = " + volumeResult.ToString("n"));
                    // Determine the surface Area of cylinder1 object
                    // And Display it in richbox
                    double areaResult = cylinder.SurfaceAreaSphere();
                    richDisplay.AppendText("\nSurface Area of cylinder = " + areaResult.ToString("n"));
                }
            }
        }

        // Validation method that check whether the user input is double
        public bool IsDOuble(TextBox textBox)
        {
            double number = 0;
            if (double.TryParse(textBox.Text, out number))
            {
                return true;

            }
            else
            {
                richDisplay.ForeColor = Color.Red;
                richDisplay.AppendText(txtRadius.Tag + " must be Numeric value.");
                textBox.Focus();
                return false;
            }

        }

        // Validation method that check whether user inupt a value in textbox
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")// You can also replace this with "String.IsNullOrEmpty(textBox.Text)"
            {
                richDisplay.ForeColor = Color.Red;
                richDisplay.AppendText(txtRadius.Tag + " is a reqiured field");
                textBox.Focus();
                return false;
            }
            return true;
        }

        private void cylinderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox.Text = "Enter the dimension of Cylinder:";
            txtHeight.Visible = true;
            lblHeight.Visible = true;
            pictureBoxDisplay.Image = imageList1.Images[0];
            
            
        }

        private void coneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox.Text = "Enter the dimension of Cone:";
            txtHeight.Visible = true;
            lblHeight.Visible = true;
            pictureBoxDisplay.Image = imageList1.Images[1];
        }

        private void speherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox.Text = "Enter the dimension of Sphere:";
            txtHeight.Visible = false;
            lblHeight.Visible = false;
            pictureBoxDisplay.Image = imageList1.Images[2];
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCone_Click(object sender, EventArgs e)
        {
            // Clear all previous(if any) display from richbox  for new calcualtion
            richDisplay.Clear();

            // Check the presence of a value in textbox fisrt using validation method
            if (IsPresent(txtRadius))
            {
                // Check if the user input value is double type
                if (IsDOuble(txtRadius))
                {
                    // Collect and assign user input to a respective variable
                    double radius = double.Parse(txtRadius.Text);
                    

                    // Create object for class Shape and take the dimension 
                    // of cone as argumnet Example Two
                    Shape cone = new Shape(radius);

                    // Get the cone radius 
                    cone.Radius = radius;

                    // Determine the volume of cone object using the method from
                    //  class Shape And Display it in richbox
                    double volumeResult = cone.VolumeCone();
                    richDisplay.AppendText("\nTotal Volume of cone = " +
                        volumeResult.ToString("n"));

                    // Determine the surface Area of cone object
                    // And Display it in richbox
                    double areaResult = cone.SurfaceAreaCone();
                    richDisplay.AppendText("\nSurface Area of cone = " +
                        areaResult.ToString("n"));
                }
            }
        }

        private void btnSphere_Click(object sender, EventArgs e)
        {
            // Clear all previous(if any) display from richbox  for new calcualtion
            richDisplay.Clear();

            // Check the presence of a value in textbox fisrt using validation method
            if (IsPresent(txtRadius))
            {
                // Check if the user input value is double type
                if (IsDOuble(txtRadius))
                {
                    // Collect and assign user input to a respective variable
                    double radius = double.Parse(txtRadius.Text);

                    // Create object for class Shape and take the dimension 
                    // of sphere as argumnet 
                    Shape sphere = new Shape(radius);

                    // Get the sphere radius 
                    sphere.Radius = radius;

                    // Determine the volume of sphere object using the method from
                    //  class Shape And Display it in richbox
                    double volumeResult = sphere.VolumeSphere();
                    richDisplay.AppendText("\nTotal Volume of sphere = " +
                        volumeResult.ToString("n"));

                    // Determine the surface Area of sphere object
                    // And Display it in richbox
                    double areaResult = sphere.SurfaceAreaSphere();
                    richDisplay.AppendText("\nSurface Area of sphere = " +
                        areaResult.ToString("n"));
                }
            }
        }

    }
    
}