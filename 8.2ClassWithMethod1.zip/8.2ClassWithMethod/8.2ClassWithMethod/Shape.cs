﻿using System;

namespace _8._2ClassWithMethod
{

    public class Shape// To move the class to new fordel select the class name and press ALT + ENTER
    {
        // Private fileds for the class Cylinder
        private double _radius;
        private double _height;
        public const double PI = 3.14159;

        // Parametrized constructor take one parameter
        public Shape(double radius)
        {
            _radius = radius;
        }

        // Parametrized constructor take two parameter
        public Shape(double length,double height)
        {
            // Assign the parameter to the fields
            _radius = length;           
            _height = height;
        }

        //  Length, Width, Height Properties for fields
        public double Radius { get { return _radius; } set { if (value > 0) { _radius = value; } } }
       
        public double Height { get { return _height; } set { if (value > 0){ _height = value; } } }

        // Method that calcualte volume(behaviors of the object)
        public double VolumeSphere()
        {
            // 4188.79
            double volumeOfSphere = (4 * PI *_radius * _radius * _radius) / 3;

            return volumeOfSphere;
        }

        // Method to calculate the surface area of Sphere
        // (behaviors of the object)
        public double SurfaceAreaSphere()
        {
            // A=4πrr
            double surfaceAreaSphere = 4 * PI * _radius * _radius;

            return surfaceAreaSphere;

        }
        // Method that calcualte volume(behaviors of the object)
        public double VolumeCylinder()
        {
            // V=πr2h
            double volumeOfCylinder = PI * _radius * _radius * _height;

            return volumeOfCylinder;
        }

        // Method to calculate the surface area of cylinder
        // (behaviors of the object)
        public double SurfaceAreaCylinder()
        {
            // A=2πrh+2πr2
            double surfaceAreaCylinder =(2 * PI * _radius * _radius * _height) +
                (2 * PI * _radius * _radius);

            return surfaceAreaCylinder;

        }
        // Method that calcualte volume(behaviors of the object)
        public double VolumeCone()
        {
            double volumeOfCone = PI * _radius * _radius * (_height/3);

            return volumeOfCone;
        }

        // Method to calculate the surface area of Cone
        // (behaviors of the object)
        public double SurfaceAreaCone()
        {
            // A=πr(r+ sqrt(h2+r2))
            double surfaceAreaCone = PI * _radius *
                ( _radius  + Math.Sqrt(( _height * _height) + (_radius * _radius)));

            return surfaceAreaCone;

        }
    }
    
}