﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8._2ClassWithMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // Clear all previous(if any) display from richbox  for new calcualtion
            richDisplay.Clear();

            // Check the presence of a value in textbox fisrt using validation method
            if (IsPresent(txtRadius) && IsPresent(txtHeight))
            {
                // Check if the user input value is double type
                if (IsDOuble(txtRadius) && IsDOuble(txtHeight))
                {
                    // Collect and assign user input to a respective variable
                    double radius = double.Parse(txtRadius.Text);
                    double height = double.Parse(txtHeight.Text);
                                       
                    // Create object for class Cylinder and take the dimension 
                    // of cylinder as argumnet Example Two
                    Cylinder cylinder = new Cylinder(radius, height);

                    // Get the cylinder Length 
                    cylinder.Radius = radius;

                    // Get the cylinder Height
                    cylinder.Height = height;

                    // Determine the Volume of cylinder object
                    // And Display it in richbox
                    double volumneResult = cylinder.Volume();
                    richDisplay.AppendText("\nVolumne of Cylinder = " + volumneResult.ToString("n"));
                    // Determine the surface Area of cylinder object
                    // And Display it in richbox
                    double areaResult = cylinder.SurfaceArea();
                    richDisplay.AppendText("\nSurface Area of Cylinder = " + areaResult.ToString("n"));

                    lblArea.Text = areaResult.ToString();
                    lblVolume.Text = volumneResult.ToString();
                }
            }
        }

        // Validation method that check whether the user input is double
        public bool IsDOuble(TextBox textBox)
        {
            double number = 0;
            if (double.TryParse(textBox.Text, out number))
            {
                return true;

            }
            else
            {
                richDisplay.ForeColor = Color.Red;
                richDisplay.AppendText(txtRadius.Tag + " must be Numeric value.");
                textBox.Focus();
                return false;
            }

        }

        // Validation method that check whether user inupt a value in textbox
        public bool IsPresent(TextBox textBox)
        {
            if (textBox.Text == "")// You can also replace this with "String.IsNullOrEmpty(textBox.Text)"
            {
                richDisplay.ForeColor = Color.Red;
                richDisplay.AppendText(txtRadius.Tag + " is a reqiured field");
                textBox.Focus();
                return false;
            }
            return true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBoxDisplay.Image = imageList1.Images[0];
        }
    }

    #region Cylinder Class

    public class Cylinder// To move the class to new fordel select the class name and press ALT + ENTER
    {
        // Private fileds for the class Cylinder
        private double _radius;
        private double _height;
        public const double PI = 3.14159;

        // implicit Constructor
        //public Cylinder(){ }

        // Parametrized constructor
        public Cylinder(double length,double height)
        {
            // Assign the parameter to the fields
            _radius = length;           
            _height = height;
        }

        //  Length, Width, Height Properties for fields
        public double Radius { get { return _radius; } set { if (value > 0) { _radius = value; } } }
       
        public double Height { get { return _height; } set { if (value > 0) { _height = value; } } }

        // Method that calcualte volume(behaviors of the object)
        public double Volume()
        {
            // V=πr2h
            double volumeOfCylinder = PI * _radius * _radius * _height;

            return volumeOfCylinder;
        }

        // Method to calculate the surface area of cylinder
        // (behaviors of the object)
        public double SurfaceArea()
        {
            // A=2πrh+2πr2
            double surfaceAreaCylinder = (2 * PI * _radius * _radius * _height) +
                (2 * PI * _radius * _radius);

            return surfaceAreaCylinder;

        }
    }
    #endregion
}